namespace ConsoleStarategyGame;

public class Napo_City: Cities
{
    public Napo_City()
    {
        Name = "Napo City";
        EmpireOwns = "Napo Empire";
        
        Income = 2889;
        Power = 2788;
        FoodStock = 5488;
        Population = 2877;

        Happiness = 0.89;
        Level = 1.1;
    }
}