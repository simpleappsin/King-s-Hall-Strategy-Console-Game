namespace ConsoleStarategyGame;

public class Player_City: Cities
{
    public Player_City()
    {
        Name = null;
        EmpireOwns = null;
        
        Income = 2289;
        Power = 1785;
        FoodStock = 5898;
        Population = 2798;

        Happiness = 0.80;
        Level = 0.89;
    }
}